package com.elrayo.modelo;

public interface IReportable {
    void generarReporte();
}
