package com.elrayo.entidad;

import com.elrayo.modelo.IReportable;

public class CierreCentral implements IReportable {
    @Override
    public void generarReporte() {
        System.out.println("📊 Reporte de cierre central generado.");
    }
}
